const express = require('express');
const {getSchool} = require('../router_function/getSchool')
const {getSchoolDepartment} = require('../router_function/getSchoolDepartment')
const {getFirstKnow} = require('../router_function/getFirstKnow')
const {getOtherKnow} = require('../router_function/getOtherKnow')
const {getKnowList} = require('../router_function/getKnowList')
const router = express.Router();
router.get('/getSchool',getSchool);
router.get('/getSchoolDepartment',getSchoolDepartment);
router.get('/getFirstKnow',getFirstKnow)
router.get('/getOtherKnow',getOtherKnow)
router.get('/getKnowList',getKnowList)
module.exports = router;