const express = require('express');
const {addTeacher} = require('../router_function/addTeacher');
const {addSchool} = require('../router_function/addSchool')
const {addDepartment} = require('../router_function/addDepartment');
const {addStudent} = require('../router_function/addStudent');
const {addUser} = require('../router_function/addUser')
const {selectStudent} = require('../router_function/selectStudent');
const {searchStudent} = require('../router_function/searchStudent');
const {disableStudent} = require('../router_function/disableStudent');
const {activateStudent} = require('../router_function/activateStudent');
const {remakeStudentPassword} = require('../router_function/remakeStudentPassword');
const {studentInfo} = require('../router_function/studentInfo');
const {setCourse} = require('../router_function/setCourse');
const {setKnowledge} = require('../router_function/setKnowledge');
const {renameKnow} = require('../router_function/renameKnow')
const {deleteKnow} = require('../router_function/deleteKnow')
const router = express.Router();
router.post('/addTeacher',addTeacher);
router.post('/addSchool',addSchool);
router.post('/addDepartment',addDepartment);
router.post('/addStudent',addStudent);
router.post('/addUser',addUser);
router.post('/selectStudent',selectStudent);
router.post('/searchStudent',searchStudent);
router.post('/disableStudent',disableStudent);
router.post('/activateStudent',activateStudent);
router.post('/remakeStudentPassword',remakeStudentPassword);
router.post('/studentInfo',studentInfo);
router.post('/setCourse',setCourse);
router.post('/setKnowledge',setKnowledge);
router.post('/renameKnow',renameKnow);
router.post('/deleteKnow',deleteKnow);
module.exports = router