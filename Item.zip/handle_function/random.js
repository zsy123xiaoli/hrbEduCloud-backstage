let random = () => {
    let code = '';
    for(let i = 0;i < 8;i++){
        let random = Math.floor(Math.random() * 9);
        code += random;
    }
    return code;
}
module.exports = {random};