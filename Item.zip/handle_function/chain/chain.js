class Chain{
    constructor(fn){
        this.fn = fn;
        this.successor = null; //默认没有下一个处理对象
    }
    setNext(successor){//主动调用设置如果条件不满足转到的下一个处理对象
        return this.successor = successor;
    }
    pass(){//主动调用，自动进行链式判断
        let ret = this.fn.apply(this, arguments);//执行处理函数
        if(ret === 'next'){
            return this.successor&&this.successor.pass.apply(this.successor, arguments);//首先判断是否有this.success，
                                                                                        //若有则返回下一个处理对象的pass(递归调用)
                                                                                        //一直递归直到符合条件的处理对象或末尾节点
        }
        return ret;
    }
}
export {
    Chain
}
