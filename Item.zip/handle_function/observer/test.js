import {newPublisher} from "./observer.js";
let loginSuccess = {};
newPublisher(loginSuccess);
let head = (function(){
    loginSuccess.listen('loginSuccess', function(){
        head.setHeader();
    });
    return {
        setHeader(data){
        console.log('设置头像');
    }
}
})()

loginSuccess.trigger('loginSuccess');