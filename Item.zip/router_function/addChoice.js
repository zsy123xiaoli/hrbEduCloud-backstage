const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let addStudent = (req,res) =>{
    let Info = req.body;
    if(req.user.REPOSITORY !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(Info, res);

}
function sqlsel(Info, res){
    let password = random();
    let timestamp = (function time() {
        let time = new Date();
        return time.getTime();
    })();
    let sql = `insert into student(QURSTION_ID,QURSTION,SEX,SCHOOL,DEPARTMENT,CLASS,MAIL,PASSWORD,TIMESTAMP) 
    values`;
    db.query(sql, Info, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(results.affectedRows !== 1){
            return res.send({status: 0, message: '添加失败'});
        }
        res.send({status:1, message: '添加成功'})
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '学生信息不能为空'
    }])
    selfCheck.add(val.id,[{
        way: 'isNull',
        err: '学号不能为空'
    }])
    selfCheck.add(val.name,[{
        way: 'isNull',
        err: '姓名不能为空'
    }])
    selfCheck.add(val.sex,[{
        way: 'isNull',
        err: '性别不能为空'
    }])
    selfCheck.add(val.school,[{
        way: 'isNull',
        err: '学校不能为空'
    }])
    selfCheck.add(val.department,[{
        way: 'isNull',
        err: '专业不能为空'
    }])
    selfCheck.add(val.class,[{
        way: 'isNull',
        err: '班级不能为空'
    }])
    selfCheck.add(val.mail,[{
        way: 'isNull',
        err: '邮箱不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addStudent
}