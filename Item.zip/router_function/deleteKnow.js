const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let deleteKnow = (req,res) =>{
    let Info = req.body;
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(Info, res);

}
function sqlsel(Info, res){
        let sql = `select KNOW_NAME from knowledge WHERE FATHER_NAME like '%${Info.name}%'`;
        let sql2 = ''
        let sql3 = `DELETE FROM knowledge WHERE KNOW_NAME='${Info.name}'`
        
        db.query(sql, Info, (err,results) =>{
            if(err){
                return res.send({status: 'test', message: err})
            }
            if(results.length != 0){
                results.forEach(val => {
                    let midsql = `DELETE FROM knowledge WHERE KNOW_NAME='${val.KNOW_NAME}'`
                    sql2 += midsql + ';';
                });
                db.query(sql2, (err,results) =>{
                    if(err){
                        return res.send({status: 0, message: err})
                    }
                    db.query(sql3, (err,results) =>{
                        if(err){
                            return res.send({status: 0, message: err})
                        }
                    return res.send({status: 1,message: '删除成功'});
                    })
                })
                return
            }else{
                db.query(sql3, (err,results) =>{
                    if(err){
                        return res.send({status: 0, message: err})
                    }
                return res.send({status: 1,message: '删除成功'});
                })
            }
        })
        return
}
    
    
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    deleteKnow
}