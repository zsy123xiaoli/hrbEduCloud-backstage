const {check} = require('../handle_function/fromCheck');
const bcrypt = require('bcrypt');
const db = require('../mysql/sql');
let getSchool = (req,res) => {
    let sql = `select NAME from school`;
    db.query(sql,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
   
module.exports = {
    getSchool
}