const db = require('../mysql/sql');
let getSchoolDepartment = (req,res) => {
    let info = req.query;
    let sql = `select DEPARTMENT from school_department where SCHOOL = ?`;
    db.query(sql,info.school,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
   
module.exports = {
    getSchoolDepartment
}