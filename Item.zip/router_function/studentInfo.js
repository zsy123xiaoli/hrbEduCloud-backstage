const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let studentInfo = (req,res) => {
    let info = req.body;
    let err = dataCheck(info);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(res,info)
}
function sqlsel(res,info){
    let sql = `select * from student where ID = ?`;
    db.query(sql,info.id,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results[0]});
    })
}
function dataCheck(info){
    let selfCheck = new check();
    selfCheck.add(info,[{
        way: 'isNullObject',
        err: '信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    studentInfo
}