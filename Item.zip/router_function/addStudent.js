const {check} = require('../handle_function/fromCheck');
const {random} = require('../handle_function/random')
const db = require('../mysql/sql');
const {sendMail} = require('../handle_function/sendMail')
const bcrypt = require('bcrypt');
let addStudent = (req,res) =>{
    let studentInfo = req.body;
    if(req.user.EDUCATIONAL_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(studentInfo);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(studentInfo, res);

}
function sqlsel(studentInfo, res){
    let password = random();
    let timestamp = (function time() {
        let time = new Date();
        return time.getTime();
    })();
    let sqlPassword = bcrypt.hashSync(password,10);
    let sql = `insert into student(ID,NAME,SEX,SCHOOL,DEPARTMENT,CLASS,MAIL,PASSWORD,TIMESTAMP) 
    values('${studentInfo.id}','${studentInfo.name}','${studentInfo.sex}','${studentInfo.school}',
    '${studentInfo.department}','${studentInfo.class}','${studentInfo.mail}','${sqlPassword}','${timestamp}')`;
    db.query(sql, studentInfo, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(results.affectedRows !== 1){
            return res.send({status: 0, message: '添加失败'});
        }
        res.send({status:1, message: '添加成功'});
        let text = `你已被添加为学生，密码为${password}`
        let mailErr = sendMail(studentInfo.mail, text)
        if(mailErr){
            return res.send({status: 0, message: '发送失败'});
        }
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '学生信息不能为空'
    }])
    selfCheck.add(val.id,[{
        way: 'isNull',
        err: '学号不能为空'
    }])
    selfCheck.add(val.name,[{
        way: 'isNull',
        err: '姓名不能为空'
    }])
    selfCheck.add(val.sex,[{
        way: 'isNull',
        err: '性别不能为空'
    }])
    selfCheck.add(val.school,[{
        way: 'isNull',
        err: '学校不能为空'
    }])
    selfCheck.add(val.department,[{
        way: 'isNull',
        err: '专业不能为空'
    }])
    selfCheck.add(val.class,[{
        way: 'isNull',
        err: '班级不能为空'
    }])
    selfCheck.add(val.mail,[{
        way: 'isNull',
        err: '邮箱不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addStudent
}