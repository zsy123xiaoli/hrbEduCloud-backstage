let acceptVideo = async (res,req) => {
        let files =  req.files
        const { index, hash } = req.body
      
        // 切片上传目录
        const chunksPath = path.join(uploadPath, hash, '/')
      
        if(!fs.existsSync(chunksPath)) {
          fs.mkdirSync(chunksPath)
        }
      
        // 切片文件
        const chunksFileName = chunksPath + hash + '-' + index
        if (fs.existsSync(chunksFileName)) {
          res.send = {
            code: 0,
            msg: '切片上传完成'
          }
          return
        }
        await uploadFn(ctx, chunksFileName).then(name => {
            res.send = {
            code: 0,
            msg: '切片上传完成'
          }
        }).catch(err => {
          console.log(err)
          res.send = {
            code: 0,
            msg: '切片上传失败'
          }
        })
      }