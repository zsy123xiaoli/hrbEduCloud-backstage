const db = require('../mysql/sql');
let getFirstKnow = (req,res) =>{
    let sql = `select KNOW_NAME from knowledge where FATHER_NAME='NONE'` ;
    db.query(sql, req.query.val, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        let arr = results[0]
        res.send({status:1, message: results});
    })
}
module.exports = {
    getFirstKnow
}