const {check} = require('../handle_function/fromCheck');
const bcrypt = require('bcrypt');
const db = require('../mysql/sql');
let addStudent = (req,res) => {
    if(req.user.EDUCATION_MANAGEMENT !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let studentInfo = [...req.body];
    let err = dataCheck(studentInfo);
    if(err){
        return res.send({status: 0, message: err})
    }
    for(let i = 0, val;val = studentInfo[i];i++){
        val[6] = bcrypt.hashSync(val[6],10);
        val.push(new Date().getTime());
    }
    sqlsel(studentInfo, res)
}
function sqlsel(studentInfo, res){
    
    let sql = `insert into student(ID,NAME,SEX,SCHOOL,CLASS,MAIL,PASSWORD,TIMESTAMP) values?`;
    db.connect();
    db.query(sql, [studentInfo], (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        db.destroy();
        res.send({status: 1,message: '添加成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addStudent
}
