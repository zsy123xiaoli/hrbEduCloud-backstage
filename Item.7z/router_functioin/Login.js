const Check = require('../handle_function/fromCheck')
const db = require('../mysql/sql')
let Login = (req,res) =>{
    let userInfo = req.body;
    let err = fromCheck(userInfo);
    if(err){
        return res.send({
            message: err
        })
    }
    sqlreq(userInfo,res);
};
function sqlreq(val,res){
    let selectSql = `select mail from student where mail=?`;
    let userInfo = val;
    db.query(selectSql, userInfo.mail, (err,results) => {
        if(err){
            return res.send({status: 1,message: err.message})
        }
        if(results.length !== 1){
            return res.send({status: 1,message: '账号不存在！'})
        }
        const passwordCheck =  bcrypt.compareSync(userInfo.password, results[0].password);
        if(!passwordCheck){
            return res.send({status: 1,message: '账号或密码错误'})
        }
        
        // const user = {...results[0], password: '', user_head: ''};
        // const userToken = jwt.sign(user, jwtkey.tokenKey, {
        //     expiresIn: '2h'
        // })
        res.send({
            status: 0,
            message: '登陆成功',
            // token:`Bearer ${userToken}`
        });
    })
}
function fromCheck(val){
    let selfCheck = new Check.check();
    selfCheck.add(val,[{
        way: 'isNull',
        err: 'req.body不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
};

module.exports = {
    Login
}