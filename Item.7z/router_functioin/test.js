const Check = require('../handle_function/fromCheck')
function fromCheck(val){
    let selfCheck = new Check.check();
    selfCheck.add(val,[{
        way: 'isNull',
        err: 'req.body不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        console.log(err);
        return err;
    }
    console.log('success');
}
fromCheck({});
