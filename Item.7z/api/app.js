const express = require('express')
const app = express()
const port = 3000

// 使用 jsonwebtoken 对用户信息进行加密
const jwt = require("jsonwebtoken");
// 使用 express-jwt 对用户信息进行解密
const expressjwt = require("express-jwt");


// 解决跨域问题，注册全局中间件
const cors = require('cors');
app.use(cors());



// 定义 secret 秘钥
const secretKey = "hrbu#$ :-)";

// 对外暴露 page 文件夹，模拟同源
app.use(express.static("./page"));

// 定义解密的中间件
app.use(expressjwt({
    secret: secretKey,
    algorithms: ["HS256"]
}).unless({
    path:[
        // /mian/
        /^\/main\//
    ]
}))

// 定义 post 获取参数的全局中间件
app.use(express.urlencoded({extended: false}));


let s;
app.post("/main/login",(req,res) => {
    const userinfo = req.body;
    console.log(userinfo);
    if(userinfo.username !== "admin" && userinfo.password !== "000000"){
        return res.send({
            status: 0,
            message: "用户不存在！请注册"
        })
    }
    const tokenStr = jwt.sign({username: userinfo.username}, secretKey, {expiresIn: "60s"});
    clearInterval(s);
    s = setTimeout(()=>{
        // 改变用户的登录状态
    },60000)
    res.send({
        status: 1,
        message: "登录成功！",
        token: tokenStr
    })
})

app.get("/api/getUsername", (req, res) => {
    console.log(req.user);
    res.send({
        status: 1,
        message: "用户名请求成功！",
        data: req.user
    })
})

app.use((err, req, res, next) => {
    console.log("err",err.name);
    if(err.name === "UnauthorizedError"){

        return res.send({
            err: err,
            status: 0,
            message: "用户鉴权失败，已处于未登录状态！"
        })
    }
    res.send({
        status: 1,
        message: "其他错误！"
    })
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`)
})


