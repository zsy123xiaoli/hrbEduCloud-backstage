module.exports = {
    env: {
        port: 8088,
        lock_path: 'npm_build.pid.lock',
    },
    url: {
        cors: "http://localhost:8081,http://localhost:8080",
        hook: "http://172.16.0.224:8088"
    }
}