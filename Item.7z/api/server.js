const express = require('express');
const server = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const expressjwt = require('express-jwt');
const {tokenKey} = require('../router_function/key')
const userGet = require('../router/SystemUserGet');
const systemUserPost = require('../router/SystemUserPost')
const userPost = require('../router/UserPost')
server.use(cors());
server.use(expressjwt({secret: tokenKey,algorithms: ['HS256']}).unless({path: [/\/login/]}));
server.use(express.urlencoded({extended: true}))
server.use(express.json())
server.use('/api/system/user',userGet);
server.use('/api/system/user',systemUserPost);
server.use('/api/user',userPost);
server.listen(3000, function(){
    console.log('http://127.0.0.1:3000启动');
})