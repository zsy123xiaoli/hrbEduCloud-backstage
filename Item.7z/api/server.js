const express = require('express');
const server = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const expressjwt = require('express-jwt');
const {tokenKey} = require('../router_function/key');
const userGet = require('../router/SystemUserGet');
const systemUserPost = require('../router/SystemUserPost');
const userPost = require('../router/UserPost');
const acceptFile = require('../router/AcceptFile')
const config = require('./config');
server.all('*', function (req, res, next) {
    let ol = config.url.cors.split(',');
    if (ol.indexOf(req.headers.origin) >= 0){
        res.header("Access-Control-Allow-Origin", req.headers.origin);
        res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
        res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
        res.header("Access-Control-Allow-Credentials", "true");
        if (req.method === 'OPTIONS') {
            res.sendStatus(200);
        }
    }
    next();

});
// server.use(cors());
server.use(expressjwt({secret: tokenKey,algorithms: ['HS256']}).unless({path: [/\/login/,/\/getSchool/,/\/getSchool/,/\/getFirstKnow/,/\/getOtherKnow/,/\/getKnowList/]}));
server.use(express.urlencoded({limit: '10mb',extended: true}))
server.use(express.json())
server.use('/api/acceptFile',acceptFile)
server.use('/api/system/user',userGet);
server.use('/api/system/user',systemUserPost);
server.use('/api/user',userPost);
server.listen(3000, function(){
    console.log('http://127.0.0.1:3000启动');
})