const express = require('express');
const server = express();
const cors = require('cors');
const bodyParser = require('body-parser');
// const expressJwt = require('express-jwt');
// const jwtErr = require('./jwterr');
const user = require('../router/SystemUserGet');
server.use(cors());
server.use(bodyParser.urlencoded({extended: false}));
//server.use(expressJwt({secret: key.tokenKey,algorithms: ['HS256']}).unless({path: [/\/login/,/\/register/,/\/sendcode/,/\/checkcode/]}));
//server.use(jwtErr.Jwterr);
server.use('/api/system/user',user);
server.listen(3030, function(){
    console.log('http://127.0.0.1:3030启动');
})
