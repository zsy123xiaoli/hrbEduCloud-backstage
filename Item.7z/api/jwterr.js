const { JsonWebTokenError } = require("jsonwebtoken");
let Jwterr = (err,req,res,next) => {
    if(err instanceof JsonWebTokenError){
        return res.send({status:1,message: err});
    }
if(err.name === 'UnauthorizedError'){
    return res.send({status:1,message: '身份认证失败'});
}
}
module.exports = {Jwterr};