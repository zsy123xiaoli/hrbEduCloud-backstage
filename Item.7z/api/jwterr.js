const jwt = require("jsonwebtoken");
const {tokenKey} = require('../router_function/key');
let Jwterr = (err,req,res,next) => {
    const token = req.headers.authorization;
    console.log(token);
    jwt.verify(token, "abc", (err,data) => {
      if (err) {
        console.log(err);
        res.send({
          status: 0,massage: 'token无效'
        })
      } else {
        console.log(data);
        next()
      }
    })
}
module.exports = {Jwterr};