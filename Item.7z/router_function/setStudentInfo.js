const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let setStudentInfo = (req,res) => {
    if(req.user.EDUCATIONAL_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let info = req.body;
    let err = dataCheck(info);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(info, res, req)
}
function sqlsel(info, res, req){
    let sql;
    if(req.user.ROLE === '管理员'){
        sql = `update student set SCHOOL = '${info.school}',DEPARTMENT = '${info.department}',CLASS='${info.class}',ID='${info.id}',NAME='${info.name}',SEX='${info.sex}',MAIL='${info.newMail}',INTRODUCE='${info.introduce}' where MAIL = '${info.mail}'`;
    }else{
        sql = `update student set DEPARTMENT = '${info.department}',CLASS='${info.class}',ID='${info.id}',NAME='${info.name}',SEX='${info.sex}',MAIL='${info.mail}',INTRODUCE='${info.introduce}' where MAIL = '${info.mail}'`;
    }
    db.query(sql, info,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: '修改成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    setStudentInfo
}
