const db = require('../mysql/sql');
let getPersonSchool = (req,res) => {
    let info = req.query;
    let sql = `select school from ${info.table} where MAIL = ${info.mail}`;
    db.query(sql,info.school,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
   
module.exports = {
    getPersonSchool
}