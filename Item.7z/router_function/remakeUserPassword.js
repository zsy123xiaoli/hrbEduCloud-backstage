const {check} = require('../handle_function/fromCheck');
const bcrypt = require('bcrypt');
const db = require('../mysql/sql');
const {sendMail} = require('../handle_function/sendMail')
let remakeUserPassword = (req,res) => {
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let userInfo = req.body.users.split(';');
    let err = dataCheck(userInfo);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(userInfo, res)
}
function sqlsel(userInfo, res){
    let sql = ``;
    let password = bcrypt.hashSync('000000', 10)
    let model_sql = `update user set PASSWORD = '${password}' where MAIL = ?`;
    userInfo.forEach((val,index) => {
        sql += db.format(model_sql, val) + ';'
    });
    db.query(sql, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: '修改成功'});
        userInfo.forEach((val,index)=>{
            let text = `你的密码已重置为000000`
            let mailErr = sendMail(val, text)
        if(mailErr){
            return res.send({status: 0, message: '发送失败'});
        }
        })
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    remakeUserPassword
}
