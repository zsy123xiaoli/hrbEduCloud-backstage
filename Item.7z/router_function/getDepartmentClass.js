const db = require('../mysql/sql');
let getDepartmentClass = (req,res) => {
    let info = req.query;
    let sql = `select NAME from class where DEPARTMENT = ${info.department}`;
    db.query(sql,info.school,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
   
module.exports = {
    getDepartmentClass
}