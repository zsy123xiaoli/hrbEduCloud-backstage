const db = require('../mysql/sql');
let getPersonClass = (req,res) => {
    let info = req.query;
    let sql = `select department from ${info.table} where MAIL = ${info.mail}`;
    db.query(sql,info.school,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
   
module.exports = {
    getPersonClass
}