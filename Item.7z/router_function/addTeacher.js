const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
const bcrypt = require('bcrypt');
const {random} = require('../handle_function/random')
const {sendMail} = require('../handle_function/sendMail')
let addTeacher = (req,res) => {
    if(req.user.EDUCATIONAL_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let userInfo = req.body;
    let err = dataCheck(userInfo);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(userInfo, res);
}
function sqlsel(userInfo, res) {
    let password = random();
    let sqlPassword = bcrypt.hashSync(password,10);
    let timestamp = (function time() {
        let time = new Date();
        return time.getTime();
    })();
    let sql =  `insert into teacher(ID,NAME,MAIL,PASSWORD,SCHOOL,DEPARTMENT,TIMESTAMP) 
    values('${userInfo.id}','${userInfo.name}','${userInfo.mail}','${sqlPassword}','${userInfo.school}','${userInfo.department}','${timestamp}')`;
    db.query(sql, userInfo, (err,results) => {
        if(err){
            return res.send({status: 0,message: err});
        }
        if(results.affectedRows !== 1){
            return res.send({status: 1,message: '添加失败'})
        }
        res.send({status: 0,message: '添加成功'});
        let text = `你已被添加为教师，密码为${password}`
        let mailErr = sendMail(userInfo.mail, text)
        if(mailErr){
            return res.send({status: 0, message: '发送失败'});
        }
    })
    
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    selfCheck.add(val.mail,[{
        way: 'isMail',
        err: '邮箱格式错误'
    }])
    selfCheck.add(val.id,[{
        way: 'isNull',
        err: 'ID不能为空'
    }])
    selfCheck.add(val.password,[{
        way: 'isNull',
        err: '密码不能为空'
    }])
    selfCheck.add(val.name,[{
        way: 'isNull',
        err: '姓名不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addTeacher
}