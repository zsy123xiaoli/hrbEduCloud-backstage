const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let setCourse = (req,res) =>{
    let Info = req.body;
    if(req.user.EDUCATIONAL_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(Info, res);

}
function sqlsel(Info, res){
    let sql = `insert into course_class(TEACHER,TEACHER_ID,COURSE,IMG,CREATE_TIME,INFO) 
    values('${Info.teacher}','${Info.teacher_id}','${Info.course}','${Info.img}','${Info.time}','${Info.info}')`;
    db.query(sql, Info, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(results.affectedRows !== 1){
            return res.send({status: 0, message: '添加失败'});
        }
        res.send({status:1, message: '添加成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '课程信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    setCourse
}