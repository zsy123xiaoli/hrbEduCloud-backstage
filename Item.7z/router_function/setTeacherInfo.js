const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let setTeacherInfo = (req,res) => {
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let info = req.body;
    let err = dataCheck(info);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(info, res, req)
}
function sqlsel(info, res, req){
    let sql;
    if(req.user.ROLE === '管理员'){
        sql = `update user set MAIL='${info.newMail}',SCHOOL='${info.department}',DEPARTMENT = '${info.department}',TEACHINGCLASS='${info.teachingclass}',SEX='${info.sex}',INTRODUCE='${info.introduce}' where MAIL = '${info.mail}'`;
    }else{
        sql = `update user set MAIL='${info.newMail}',DEPARTMENT = '${info.department}',TEACHINGCLASS='${info.teachingclass}',SEX='${info.sex}',INTRODUCE='${info.introduce}' where MAIL = '${info.mail}'`;
    }
    db.query(sql, info,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: '修改成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    setTeacherInfo
}
