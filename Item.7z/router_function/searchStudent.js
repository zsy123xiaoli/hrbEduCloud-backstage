const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let searchStudent = (req,res) => {
    let info = req.body;
    let err = dataCheck(info);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(res,info)
}
function sqlsel(res,info){
    
    let sql = `SELECT ID,NAME,SEX,DEPARTMENT,SCHOOL,MAIL,FORBIDDEN FROM student WHERE CONCAT(IFNULL(ID,''),IFNULL(NAME,''),IFNULL(CLASS,'')) LIKE '%${info.val}%' ORDER BY TIMESTAMP LIMIT ${15*(info.num-1)},15;`;
    db.query(sql,info,(err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status: 1,message: results});
    })
}
function dataCheck(info){
    let selfCheck = new check();
    selfCheck.add(info,[{
        way: 'isNullObject',
        err: '信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    searchStudent
}