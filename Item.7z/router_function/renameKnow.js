const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let renameKnow = (req,res) =>{
    let Info = req.body;
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(Info, res);

}
function sqlsel(Info, res){
        let sql = `select KNOW_NAME,FATHER_NAME from knowledge WHERE FATHER_NAME like '%${Info.name}%'`;
        let sql2 = ''
        let sql3 = `update knowledge set KNOW_NAME = '${Info.newName}' where KNOW_NAME = '${Info.name}'`
        
        db.query(sql, Info, (err,results) =>{
            if(err){
                return res.send({status: 'test', message: err})
            }
            if(results.length != 0){
                results.forEach(val => {
                    let arr = val.FATHER_NAME.split('|');
                    arr.forEach((val,index,arr) => {
                        if(val == Info.name){
                            arr[index] = Info.newName;
                        }
                    })
                    let str = arr.join('|');
                    let midsql = `update knowledge set FATHER_NAME = '${str}' where FATHER_NAME like '%${Info.name}%'`
                    sql2 += midsql + ';';
                });
                db.query(sql2, (err,results) =>{
                    if(err){
                        return res.send({status: 0, message: err})
                    }
                    db.query(sql3, (err,results) =>{
                        if(err){
                            return res.send({status: 0, message: err})
                        }
                    return res.send({status: 1,message: '修改成功'});
                    })
                })
                return
            }else{
                db.query(sql3, (err,results) =>{
                    if(err){
                        return res.send({status: 0, message: err})
                    }
                return res.send({status: 1,message: '修改成功'});
                })
            }
        })
        return
}
    
    
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    renameKnow
}