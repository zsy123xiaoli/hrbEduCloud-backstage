const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let addSchool = (req,res) =>{
    let schoolInfo = req.body;
    if(req.user.SYSTEM_MANAGEMENT !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(schoolInfo);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(schoolInfo, res);

}
function sqlsel(schoolInfo, res){
    let timestamp = (function time() {
        let time = new Date();
        return time.getTime();
    })();
    let sql = `insert into school(ID,NAME,PRINCIPAL,ADDRESS,TIMESTAMP) 
    values('${schoolInfo.id}','${schoolInfo.name}','${schoolInfo.principal}','${schoolInfo.address}','${timestamp}')`;
    db.query(sql, schoolInfo, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(results.affectedRows !== 1){
            return res.send({status: 0, message: '学校添加失败'});
        }
        res.send({message: '添加成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '学校信息不能为空'
    }])
    selfCheck.add(val.name,[{
        way: 'isNull',
        err: '学校编号不能为空'
    }])
    selfCheck.add(val.name,[{
        way: 'isNull',
        err: '学校名字不能为空'
    }])
    selfCheck.add(val.principal,[{
        way: 'isNull',
        err: '学校校长不能为空'
    }])
    selfCheck.add(val.address,[{
        way: 'isNull',
        err: '学校地址不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addSchool
}