const multer=require("multer");
function acceptFile(req,res,next){
	let upload=multer({dest:"../file/"}).single("picture");
	upload(req,res,(err)=>{
		if(err){
	        res.send("err:"+err);
	    }else{
	        req.body.photo=req.file.filename;
	        res.send({status: 1,message: '上传成功'})
	    }
	})
}
module.exports = {
    acceptFile
}