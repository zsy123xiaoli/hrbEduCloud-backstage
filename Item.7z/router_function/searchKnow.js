const db = require('../mysql/sql');
let getKnow2 = (req,res) =>{
    let sql = `select KNOW_NAME,FATHER_NAME from knowledge where KNOW_NAME = ?` ;
    db.query(sql, req.query.val, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(Object.keys(results[0]).length !== 0){
            let arr = [];
            arr.unshift(results[0].KNOW_NAME);
            if(results[0].FATHER_NAME != 'NONE'){
                arr.unshift(results[0].FATHER_NAME);
            }
        }
    })
}
module.exports = {
    getKnow2
}