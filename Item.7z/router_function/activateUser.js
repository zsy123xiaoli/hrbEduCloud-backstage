const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let activateUser = (req,res) => {
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let Info = req.body.users.split(';')
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(Info, res)
}
function sqlsel(Info, res){
    let sql = ``;
    let model_sql = 'update user set FORBIDDEN = 0 where MAIL = ?';
    Info.forEach((val,index) => {
        sql += db.format(model_sql, val) + ';'
    });
    db.connect();
    db.query(sql, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        db.destroy();
        return res.send({status: 1,message: '激活成功'});
    })
    return
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    activateUser
}
