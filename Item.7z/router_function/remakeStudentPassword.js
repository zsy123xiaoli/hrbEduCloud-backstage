const {check} = require('../handle_function/fromCheck');
const bcrypt = require('bcrypt');
const db = require('../mysql/sql');
const {sendMail} = require('../handle_function/sendMail')
let disableStudent = (req,res) => {
    if(req.user.EDUCATIONAL_MANAGE !== 2){
        return res.send({status: 0,message: '你没有此权限'})
    }
    let studentInfo = [...req.body];
    let err = dataCheck(studentInfo);
    let mail = [];
    for(let i=0,val;val=studentInfo[i];i++){
        mail[1] = val[1];
        val.pop();
    }
    if(err){
        return res.send({status: 0, message: err})
    }
    sqlsel(studentInfo, res)
}
function sqlsel(studentInfo, res){
    let sql = ``;
    let password = bcrypt.hashSync('000000', 10)
    let model_sql = `update student set PASSWORD = ${password} where ID = ?`;
    studentInfo.forEach((val,index) => {
        sql += db.format(model_sql, val) + ';'
    });
    db.connect();
    db.query(sql, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        db.destroy();
        sendMail.
        res.send({status: 1,message: '修改成功'});
        mail.forEach((val,index)=>{
            let mailErr = sendMail(val, '000000')
        if(mailErr){
            return res.send({status: 0, message: '发送失败'});
        }
        })
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '个人信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    disableStudent
}
