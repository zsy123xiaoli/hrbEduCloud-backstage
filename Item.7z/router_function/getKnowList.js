const db = require('../mysql/sql');
let getKnowList = (req,res) =>{
    let sql = `select KNOW_NAME,FATHER_NAME from knowledge LIMIT ${50*(req.query.val-1)},50;` ;
    db.query(sql, req.query.val, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status:1, message: results});
    })
}
module.exports = {
    getKnowList
}