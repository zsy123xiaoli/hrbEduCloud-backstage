const db = require('../mysql/sql');
let getOtherKnow = (req,res) =>{
    let sql = `select KNOW_NAME from knowledge where FATHER_NAME like '%${req.query.val}%'` ;
    db.query(sql, req.query.val, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        res.send({status:1, message: results});
    })
}
module.exports = {
    getOtherKnow
}