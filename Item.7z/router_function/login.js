const Check = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')
const {tokenKey} = require('./key')
let Login = (req,res) =>{
    let userInfo = req.body;
    let err = fromCheck(userInfo); //获得数据验证信息
    if(err){
        return res.send({
            status: 0,
            message: err
        })
    }
    sqlreq('user', userInfo,res, 1); //执行查询
    
};
function sqlreq(table,val,res,selectNum){
    let selectSql = `select * from ${table} where mail=?`;
    let userInfo = val;
    db.query(selectSql, userInfo.mail,(err, results) => {
    if(err){
        return  res.send({status: 0,message: err});
    }
    if(results.length !== 1 && selectNum == 1){ //如果管理员表没有此用户
        selectNum++;
        sqlreq('teacher', userInfo,res,selectNum)
        return
    }
    if(results.length !== 1 && selectNum == 2){ //如果教师表没有此用户
        selectNum++;
        sqlreq('student', userInfo,res,selectNum)
        return
    }
    if(results.length !== 1 && selectNum == 3){ //如果三个表都没有则return错误
        return  res.send({status: 0,message: `用户不存在！${selectNum}`});
    }
    if(results[0].FORBIDDEN === 1){
        return res.send({status: 0,message: '此账号已禁封'})
    }
    const passwordCheck =  bcrypt.compareSync(userInfo.password, results[0].PASSWORD);
    if(!passwordCheck && selectNum === 1){ 
        sqlreq('teacher', userInfo,res,selectNum)
        return
    }
    if(!passwordCheck){
        return res.send({status: 0,message: '账号或密码错误'})
    }
    selPostiton(results[0],res)
    }); 
}
function selPostiton(userInfo, res){
    let sql = 'select * from permission where role=?'
    db.query(sql,userInfo.ROLE,(err,results)=>{
        if(err){
            return res.send({status: 0,message: err});
        }
        if(results.length !== 1){
            return res.send({status: 0,message: '未知错误'});
        }
        const position = {...results[0]};
        const user = {...userInfo, PASSWORD: ''};
   
    let newUser = Object.assign(user,position);
    const userToken = jwt.sign( newUser, tokenKey, {
        expiresIn: '2h'
    })
    res.send({
        status: 0,
        message: '登陆成功',
        token: userToken
    });
    })
}
function fromCheck(val){
    let selfCheck = new Check.check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: 'req.body不能为空'
    }])
    selfCheck.add(val.mail,[{
        way: 'isNull',
        err: '邮箱不能为空'
    },{
        way: 'isMail',
        err: '邮箱格式不正确'
    }])
    selfCheck.add(val.password,[{
        way: 'isNull',
        err: '密码不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
};

module.exports = {
    Login
}