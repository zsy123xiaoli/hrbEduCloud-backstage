const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let addDepartment = (req,res) =>{
    let departmentInfo = req.body;
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(departmentInfo);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(departmentInfo, res);

}
function sqlsel(departmentInfo, res){
    let timestamp = (function time() {
        let time = new Date();
        return time.getTime();
    })();
    let sql = `insert into school_department(SCHOOL,DEPARTMENT,DEPARTMENT_ID,DEAN,CREATE_TIME) 
    values('${departmentInfo.school}','${departmentInfo.department}','${departmentInfo.id}','${departmentInfo.dean}','${timestamp}')`;
    db.query(sql, departmentInfo, (err,results) =>{
        if(err){
            return res.send({status: 0, message: err})
        }
        if(results.affectedRows !== 1){
            return res.send({status: 0, message: '专业添加失败'});
        }
        res.send({message: '添加成功'});
    })
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '专业信息不能为空'
    }])
    selfCheck.add(val.school,[{
        way: 'isNull',
        err: '学校不能为空'
    }])
    selfCheck.add(val.department,[{
        way: 'isNull',
        err: '专业名称不能为空'
    }])
    selfCheck.add(val.id,[{
        way: 'isNull',
        err: '专业编号不能为空'
    }])
    selfCheck.add(val.id,[{
        way: 'isNull',
        err: '专业编号不能为空'
    }])
    selfCheck.add(val.dean,[{
        way: 'isNull',
        err: '系主任不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    addDepartment
}