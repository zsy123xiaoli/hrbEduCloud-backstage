const {check} = require('../handle_function/fromCheck');
const db = require('../mysql/sql');
let setKnowledge = (req,res) =>{
    let Info = req.body;
    if(req.user.SYSTEM_MANAGE !== 2){
        return res.send({status: 0,message: '没有此权限'})
    }
    let err = dataCheck(Info);
    if(err){
        return res.send({status: 0,message: err})
    }
    sqlsel(Info, res);

}
function sqlsel(Info, res){
    selectLevel(Info.father_name).then((value)=>{
        console.log(value);
        if(typeof(value[0]) !== 'number'){
            return res.send({status: 0,message: '未知错误'})
        }
        let self_father
        if(value[1] != 'NONE'){
            self_father = `${value[1]}|${Info.father_name}`
        }else{
            self_father = `${Info.father_name}`
        }
        let sql = `insert into knowledge(KNOW_NAME,FATHER_NAME,LEVEL,TYPE,SCHOOL) 
        values('${Info.name}','${self_father}','${value[0]}',1,'${Info.school}')`;
        db.query(sql, Info, (err,results) =>{
            if(err){
                return res.send({status: 0, message: err})
            }
            if(results.affectedRows !== 1){
                return res.send({status: 0, message: '添加失败'});
            }
            res.send({status:1, message: '添加成功'});
        })
    }).catch(value=> {
        res.send({status: 0,message: value})
    });
    
}
function selectLevel(val){  
    return new Promise((resolve,reject) => {
        let father_lever,father_name;
        let sql = `select LEVEL,FATHER_NAME from knowledge where KNOW_NAME = '${val}'`
        db.query(sql, val, (err,results) =>{
            if(err){
                reject(err);
            }
            if(results.length === 0){
                reject('没有此父节点')
            }else{
                father_lever = results[0].LEVEL + 1;
                father_name = results[0].FATHER_NAME;
                let arr = [father_lever,father_name]
                resolve(arr);
            }
        })
    }) 
}
function dataCheck(val){
    let selfCheck = new check();
    selfCheck.add(val,[{
        way: 'isNullObject',
        err: '信息不能为空'
    }])
    let err = selfCheck.start();
    if(err){
        return err;
    }
}
module.exports = {
    setKnowledge
}