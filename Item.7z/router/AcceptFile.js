const express = require('express');
const cors = require('cors')
let corsOptions = {
  origin: 'http://192.168.0.104.8080',
  optionsSuccessStatus: 200 
}
const { acceptFile } = require('../router_function/acceptFile');
const router = express.Router();
router.post('/Picture',acceptFile);
module.exports = router;