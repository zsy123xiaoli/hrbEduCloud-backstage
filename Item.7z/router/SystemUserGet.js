const express = require('express');
const { Login } = require('../router_functioin/Login');
const router = express.Router();
router.get('/login',Login);
module.exports = router;