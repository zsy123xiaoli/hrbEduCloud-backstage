const express = require('express');
const { addTeacher } = require('../router_function/addTeacher');
const {addSchool} = require('../router_function/addSchool')
const {addDepartment} = require('../router_function/addDepartment');
const {addStudent} = require('../router_function/addStudent');
const {selectStudent} = require('../router_function/selectStudent');
const {searchStudent} = require('../router_function/searchStudent');
const {disableStudent} = require('../router_function/disableStudent');
const{activateStudent} = require('../router_function/activateStudent');
const router = express.Router();
router.post('/addTeacher',addTeacher);
router.post('/addSchool',addSchool);
router.post('/addDepartment',addDepartment);
router.post('/addStudent',addStudent);
router.post('/selectStudent',selectStudent);
router.post('/searchStudent',searchStudent);
router.post('/disableStudent',disableStudent);
router.post('/activateStudent',activateStudent);
module.exports = router