let fromCheck = {
    isNull(val, err){ //是否为空
        if(val === '' || Object.keys(val).length === 0){
            return err;
        }
    },
    maxLength(val, maxNum, err){ //最大长度
        if(val.length > maxNum){
            return err;
        }
    },
    minLength(val, minNum, err){ //最小长度
        if(val.length < minNum){
            return err;
        }
    },
    isPhone(val, err){ //是否符合手机号格式
        let phoneCheck = /^1(3\d|4[5-9]|5[0-35-9]|6[567]|7[0-8]|8\d|9[0-35-9])\d{8}$/;
        if(!phoneCheck.test(val)){
            return err;
        }
    },
    isMail(val, err){ //是否符合qq邮箱格式
        let phoneCheck = /[1-9]\d{7,10}@qq\.com`g/;
        if(!phoneCheck.test(val)){
            return err;
        }
    }
}
let check = function(){
    this.cache = []; //用于存储要执行的函数
}
check.prototype.add = function(val, rules){
    let self = this;
    for(let i = 0,rule;rule = rules[i++];){
        (function(rule){ //立即执行函数，处理完参数后立刻将函数压栈 
            let wayAry = rule.way.split(':');
            let err = rule.err;
            self.cache.push(function(){
                let way = wayAry.shift();
                wayAry.unshift(val);
                wayAry.push(err);
                return fromCheck[way].apply(val, wayAry);
            })
        })(rule)
    }
};
check.prototype.start = function(){//遍历数组依次执行函数
    for(let i = 0, wayFunc; wayFunc = this.cache[i++];){
        let err = wayFunc();
        if(err){
            return err;
        }
    }
}
module.exports = {
    check
}
