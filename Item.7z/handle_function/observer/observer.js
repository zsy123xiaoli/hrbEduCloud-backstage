let event = {
    funcList: {},
    listen: function(key, fn){
        if(!this.funcList[key]){
            this.funcList[key] = [];
        }
        this.funcList[key].push(fn);
    },
    trigger: function(){   
        let key = Array.prototype.shift.call(arguments);
        let fns = this.funcList[key];
        if(!fns || fns.length === 0){
            return false;
        }
        for(let i = 0, fn; fn = fns[i++];){
            fn.apply(this, arguments);
        }
    },
    remove: function(key, fn){
        let fns = this.funcList[key];
        if(!fns){
            return false;
        }
        if(!fn){
            fns.length = 0;
        }
        for(let i = fns.length - 1; i >= 0; i--){
            let removeFn = fns[i];
            if(removeFn === fn){
                fns.splice(i, 1);
            }
        }
    }
}
let newPublisher = function(obj){
    for(let i in event){
        obj[i] = event[i];
    }
}
export {
    newPublisher
}
