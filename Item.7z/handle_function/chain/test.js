import { Chain } from "./chain.js";
let permission3 = function(value){ //处理函数，这里自己写
    if(value === 3){
        console.log('3级权限');
    }else{
        return 'next';
    }
}
let permission2 = function(value){
    if(value === 2){
        console.log('2级权限');
    }else{
        return 'next';
    }
}
let permission1 = function(value){
    if(value === 1){
        console.log('1级权限');
    }else{
        return 'next';
    }
}
let chainTest3 = new Chain(permission3); //实例化对象并传入处理函数
let chainTest2 = new Chain(permission2);
let chainTest1 = new Chain(permission1);
chainTest3.setNext(chainTest2);//为当前处理对象设置下一个处理节点 ，如果chainTest3不满足则进入chainTest2
chainTest2.setNext(chainTest1);//同上如果chainTest2不满足则进入chainTest1
chainTest3.pass(1);//开始链式处理

// 优点：将链式过程与实际处理函数解耦
// 可以随意增加节点
// 注：处理函数参数可以是任意个，这里只是演示
// 如果不跳转下一个节点一定要在处理函数return 'next'

