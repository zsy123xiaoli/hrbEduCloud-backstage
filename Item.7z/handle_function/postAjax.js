let postAjax = function(url, info){
        new Promise((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.open('POST', url);
            xhr.setRequestHeader('content-type', 'application/x-www-from-urlencoded')
            xhr.send(info);
            xhr.onload = function(){
                if(this.status === 200){
                    resolve(JSON.parse(this.response));
                }else(
                    reject('请求失败')
                )
            }
        }) 
}