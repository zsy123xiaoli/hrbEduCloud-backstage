const nodemailer = require('nodemailer')
let sendMail = (mail,val) => {
        let config = {
            host: 'smtp.qq.com',
            port: 465,
            auth: {
                user: '1836349958@qq.com',
                pass: 'zmgnwtazbskvcfdd'
            }
        };
        let mailText = {
            from: '1836349958@qq.com>',
            subject: '你好',
            to: mail,
            text: `密码为:${val}`
        };
        let transporter = nodemailer.createTransport(config);
        let err = transporter.sendMail(mailText, function(error, info){
            if(error) {
                return error;
            }
        });
        if(err){
            return err;
        }
    }
    module.exports = {
        sendMail
    }