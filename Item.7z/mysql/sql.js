const mysql = require('mysql');
const key = mysql.createConnection({
    host:'127.0.0.1',
    user: 'root',
    password: '123456',
    database: 'item'
})
module.exports = key;